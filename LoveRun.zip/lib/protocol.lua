protocol = {}

--消息类型

--玩家位置，"p,x"
POSITION = "p"

--玩家跳跃，"j,x"
JUMP = "j"

--玩家摔倒，"t,x"
TUMBLE = "t"


return protocol