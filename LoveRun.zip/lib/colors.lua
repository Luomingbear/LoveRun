colors = {}

colors.backgroud = {31,28,24,255} --背景颜色
colors.zongse = {180,170,156,255} --棕色
colors.white = {255,255,255,255} --白色
colors.red = {195,64,80,255} --红色
colors.red = {95,205,228,255} --蓝色

return colors
